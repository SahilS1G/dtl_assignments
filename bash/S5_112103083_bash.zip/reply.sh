#!/bin/bash

echo "enter the name"
read
echo "the names are $REPLY"
