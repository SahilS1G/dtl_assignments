#!/bin/bash

read -p "username : " user_var
read -sp "password : " pass_var
echo
echo "username" : $user_var
echo "password" : $pass_var

