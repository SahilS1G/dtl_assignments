#!/usr/bin/env bash
for i in {0..10..2}
do
  echo $i
done

echo 
echo

for (( j=0; j<5; j++ ))
do
  echo $j
done
