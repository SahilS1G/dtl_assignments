#!/bin/bash

echo "enter names : "

read -a names 
echo "Names : ${names[0]}, ${names[1]}"
