#!/bin/bash

echo our shell name is $BASH
echo our shell version is $BASH_VERSION
echo our home directory is $HOME
echo $USER
echo $PWD

#user defined names
name=sahil
val=10
echo the name is $name
echo the val is $val
