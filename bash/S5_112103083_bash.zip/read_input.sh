#/bin/bash

echo "enter names :"
read name1 name2 name3

echo "enterd name $name1, $name2, $name3"
