#!/bin/bash
#this is a comment 
echo "hello world" #this is also a comment


